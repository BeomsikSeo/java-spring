package 상속확인문제;

public class Car {
	int tyre;
	String category;
	
	public void run() {
		System.out.println("신나게 달리다");
	}
	
	public void breakPedal() {
		System.out.println("멈추다");
	}
}
